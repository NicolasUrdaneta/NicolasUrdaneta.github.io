const getCurrentUrl = () => {
	return window.location.pathname + window.location.search;
};

export default getCurrentUrl;
