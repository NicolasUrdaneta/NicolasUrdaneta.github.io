var cov_lvhh8p8kb = function () {
  var path = "/Users/georgymarchuk/www/@swup/swup/src/index.js";
  var hash = "0448e8517c583c1aa3782c6d0101826f4f94e83b";
  var global = new Function("return this")();
  var gcv = "__coverage__";
  var coverageData = {
    path: "/Users/georgymarchuk/www/@swup/swup/src/index.js",
    statementMap: {
      "0": {
        start: {
          line: 21,
          column: 17
        },
        end: {
          line: 37,
          column: 3
        }
      },
      "1": {
        start: {
          line: 35,
          column: 4
        },
        end: {
          line: 35,
          column: 59
        }
      },
      "2": {
        start: {
          line: 40,
          column: 18
        },
        end: {
          line: 43,
          column: 3
        }
      },
      "3": {
        start: {
          line: 46,
          column: 2
        },
        end: {
          line: 67,
          column: 4
        }
      },
      "4": {
        start: {
          line: 70,
          column: 2
        },
        end: {
          line: 70,
          column: 30
        }
      },
      "5": {
        start: {
          line: 72,
          column: 2
        },
        end: {
          line: 72,
          column: 29
        }
      },
      "6": {
        start: {
          line: 74,
          column: 2
        },
        end: {
          line: 74,
          column: 25
        }
      },
      "7": {
        start: {
          line: 76,
          column: 2
        },
        end: {
          line: 76,
          column: 20
        }
      },
      "8": {
        start: {
          line: 78,
          column: 2
        },
        end: {
          line: 78,
          column: 23
        }
      },
      "9": {
        start: {
          line: 80,
          column: 2
        },
        end: {
          line: 80,
          column: 31
        }
      },
      "10": {
        start: {
          line: 83,
          column: 2
        },
        end: {
          line: 83,
          column: 27
        }
      },
      "11": {
        start: {
          line: 84,
          column: 2
        },
        end: {
          line: 84,
          column: 25
        }
      },
      "12": {
        start: {
          line: 85,
          column: 2
        },
        end: {
          line: 85,
          column: 27
        }
      },
      "13": {
        start: {
          line: 86,
          column: 2
        },
        end: {
          line: 86,
          column: 31
        }
      },
      "14": {
        start: {
          line: 87,
          column: 2
        },
        end: {
          line: 87,
          column: 35
        }
      },
      "15": {
        start: {
          line: 88,
          column: 2
        },
        end: {
          line: 88,
          column: 15
        }
      },
      "16": {
        start: {
          line: 89,
          column: 2
        },
        end: {
          line: 89,
          column: 17
        }
      },
      "17": {
        start: {
          line: 90,
          column: 2
        },
        end: {
          line: 90,
          column: 43
        }
      },
      "18": {
        start: {
          line: 91,
          column: 2
        },
        end: {
          line: 91,
          column: 51
        }
      },
      "19": {
        start: {
          line: 92,
          column: 2
        },
        end: {
          line: 92,
          column: 33
        }
      },
      "20": {
        start: {
          line: 93,
          column: 2
        },
        end: {
          line: 93,
          column: 22
        }
      },
      "21": {
        start: {
          line: 94,
          column: 2
        },
        end: {
          line: 94,
          column: 17
        }
      },
      "22": {
        start: {
          line: 95,
          column: 2
        },
        end: {
          line: 95,
          column: 21
        }
      },
      "23": {
        start: {
          line: 96,
          column: 2
        },
        end: {
          line: 96,
          column: 31
        }
      },
      "24": {
        start: {
          line: 99,
          column: 2
        },
        end: {
          line: 99,
          column: 16
        }
      },
      "25": {
        start: {
          line: 104,
          column: 2
        },
        end: {
          line: 107,
          column: 3
        }
      },
      "26": {
        start: {
          line: 105,
          column: 3
        },
        end: {
          line: 105,
          column: 44
        }
      },
      "27": {
        start: {
          line: 106,
          column: 3
        },
        end: {
          line: 106,
          column: 10
        }
      },
      "28": {
        start: {
          line: 110,
          column: 2
        },
        end: {
          line: 115,
          column: 4
        }
      },
      "29": {
        start: {
          line: 116,
          column: 2
        },
        end: {
          line: 116,
          column: 71
        }
      },
      "30": {
        start: {
          line: 119,
          column: 13
        },
        end: {
          line: 119,
          column: 89
        }
      },
      "31": {
        start: {
          line: 120,
          column: 2
        },
        end: {
          line: 120,
          column: 48
        }
      },
      "32": {
        start: {
          line: 121,
          column: 2
        },
        end: {
          line: 123,
          column: 3
        }
      },
      "33": {
        start: {
          line: 122,
          column: 3
        },
        end: {
          line: 122,
          column: 29
        }
      },
      "34": {
        start: {
          line: 126,
          column: 2
        },
        end: {
          line: 126,
          column: 70
        }
      },
      "35": {
        start: {
          line: 129,
          column: 2
        },
        end: {
          line: 131,
          column: 5
        }
      },
      "36": {
        start: {
          line: 130,
          column: 3
        },
        end: {
          line: 130,
          column: 20
        }
      },
      "37": {
        start: {
          line: 134,
          column: 2
        },
        end: {
          line: 142,
          column: 4
        }
      },
      "38": {
        start: {
          line: 145,
          column: 2
        },
        end: {
          line: 145,
          column: 31
        }
      },
      "39": {
        start: {
          line: 148,
          column: 2
        },
        end: {
          line: 148,
          column: 57
        }
      },
      "40": {
        start: {
          line: 151,
          column: 2
        },
        end: {
          line: 151,
          column: 32
        }
      },
      "41": {
        start: {
          line: 156,
          column: 2
        },
        end: {
          line: 156,
          column: 42
        }
      },
      "42": {
        start: {
          line: 157,
          column: 2
        },
        end: {
          line: 157,
          column: 46
        }
      },
      "43": {
        start: {
          line: 160,
          column: 2
        },
        end: {
          line: 160,
          column: 74
        }
      },
      "44": {
        start: {
          line: 163,
          column: 2
        },
        end: {
          line: 163,
          column: 21
        }
      },
      "45": {
        start: {
          line: 166,
          column: 2
        },
        end: {
          line: 168,
          column: 5
        }
      },
      "46": {
        start: {
          line: 167,
          column: 3
        },
        end: {
          line: 167,
          column: 22
        }
      },
      "47": {
        start: {
          line: 171,
          column: 2
        },
        end: {
          line: 173,
          column: 5
        }
      },
      "48": {
        start: {
          line: 172,
          column: 3
        },
        end: {
          line: 172,
          column: 40
        }
      },
      "49": {
        start: {
          line: 176,
          column: 2
        },
        end: {
          line: 176,
          column: 13
        }
      },
      "50": {
        start: {
          line: 179,
          column: 2
        },
        end: {
          line: 179,
          column: 32
        }
      },
      "51": {
        start: {
          line: 182,
          column: 2
        },
        end: {
          line: 182,
          column: 60
        }
      },
      "52": {
        start: {
          line: 187,
          column: 2
        },
        end: {
          line: 238,
          column: 3
        }
      },
      "53": {
        start: {
          line: 189,
          column: 3
        },
        end: {
          line: 234,
          column: 4
        }
      },
      "54": {
        start: {
          line: 190,
          column: 4
        },
        end: {
          line: 190,
          column: 42
        }
      },
      "55": {
        start: {
          line: 191,
          column: 4
        },
        end: {
          line: 191,
          column: 27
        }
      },
      "56": {
        start: {
          line: 192,
          column: 17
        },
        end: {
          line: 192,
          column: 47
        }
      },
      "57": {
        start: {
          line: 193,
          column: 4
        },
        end: {
          line: 233,
          column: 5
        }
      },
      "58": {
        start: {
          line: 195,
          column: 5
        },
        end: {
          line: 216,
          column: 6
        }
      },
      "59": {
        start: {
          line: 197,
          column: 6
        },
        end: {
          line: 197,
          column: 51
        }
      },
      "60": {
        start: {
          line: 198,
          column: 22
        },
        end: {
          line: 198,
          column: 60
        }
      },
      "61": {
        start: {
          line: 199,
          column: 6
        },
        end: {
          line: 212,
          column: 7
        }
      },
      "62": {
        start: {
          line: 200,
          column: 7
        },
        end: {
          line: 208,
          column: 9
        }
      },
      "63": {
        start: {
          line: 211,
          column: 7
        },
        end: {
          line: 211,
          column: 72
        }
      },
      "64": {
        start: {
          line: 215,
          column: 6
        },
        end: {
          line: 215,
          column: 43
        }
      },
      "65": {
        start: {
          line: 219,
          column: 5
        },
        end: {
          line: 221,
          column: 6
        }
      },
      "66": {
        start: {
          line: 220,
          column: 6
        },
        end: {
          line: 220,
          column: 44
        }
      },
      "67": {
        start: {
          line: 224,
          column: 28
        },
        end: {
          line: 226,
          column: 6
        }
      },
      "68": {
        start: {
          line: 229,
          column: 5
        },
        end: {
          line: 232,
          column: 7
        }
      },
      "69": {
        start: {
          line: 237,
          column: 3
        },
        end: {
          line: 237,
          column: 48
        }
      },
      "70": {
        start: {
          line: 242,
          column: 2
        },
        end: {
          line: 242,
          column: 55
        }
      },
      "71": {
        start: {
          line: 242,
          column: 48
        },
        end: {
          line: 242,
          column: 55
        }
      },
      "72": {
        start: {
          line: 243,
          column: 15
        },
        end: {
          line: 243,
          column: 81
        }
      },
      "73": {
        start: {
          line: 244,
          column: 2
        },
        end: {
          line: 248,
          column: 3
        }
      },
      "74": {
        start: {
          line: 245,
          column: 3
        },
        end: {
          line: 245,
          column: 41
        }
      },
      "75": {
        start: {
          line: 247,
          column: 3
        },
        end: {
          line: 247,
          column: 26
        }
      },
      "76": {
        start: {
          line: 249,
          column: 2
        },
        end: {
          line: 249,
          column: 39
        }
      },
      "77": {
        start: {
          line: 250,
          column: 2
        },
        end: {
          line: 250,
          column: 51
        }
      }
    },
    fnMap: {
      "0": {
        name: "(anonymous_0)",
        decl: {
          start: {
            line: 19,
            column: 1
          },
          end: {
            line: 19,
            column: 2
          }
        },
        loc: {
          start: {
            line: 19,
            column: 25
          },
          end: {
            line: 100,
            column: 2
          }
        },
        line: 19
      },
      "1": {
        name: "(anonymous_1)",
        decl: {
          start: {
            line: 34,
            column: 25
          },
          end: {
            line: 34,
            column: 26
          }
        },
        loc: {
          start: {
            line: 34,
            column: 41
          },
          end: {
            line: 36,
            column: 4
          }
        },
        line: 34
      },
      "2": {
        name: "(anonymous_2)",
        decl: {
          start: {
            line: 93,
            column: 13
          },
          end: {
            line: 93,
            column: 14
          }
        },
        loc: {
          start: {
            line: 93,
            column: 19
          },
          end: {
            line: 93,
            column: 21
          }
        },
        line: 93
      },
      "3": {
        name: "(anonymous_3)",
        decl: {
          start: {
            line: 102,
            column: 1
          },
          end: {
            line: 102,
            column: 2
          }
        },
        loc: {
          start: {
            line: 102,
            column: 10
          },
          end: {
            line: 152,
            column: 2
          }
        },
        line: 102
      },
      "4": {
        name: "(anonymous_4)",
        decl: {
          start: {
            line: 129,
            column: 31
          },
          end: {
            line: 129,
            column: 32
          }
        },
        loc: {
          start: {
            line: 129,
            column: 43
          },
          end: {
            line: 131,
            column: 3
          }
        },
        line: 129
      },
      "5": {
        name: "(anonymous_5)",
        decl: {
          start: {
            line: 154,
            column: 1
          },
          end: {
            line: 154,
            column: 2
          }
        },
        loc: {
          start: {
            line: 154,
            column: 11
          },
          end: {
            line: 183,
            column: 2
          }
        },
        line: 154
      },
      "6": {
        name: "(anonymous_6)",
        decl: {
          start: {
            line: 166,
            column: 31
          },
          end: {
            line: 166,
            column: 32
          }
        },
        loc: {
          start: {
            line: 166,
            column: 43
          },
          end: {
            line: 168,
            column: 3
          }
        },
        line: 166
      },
      "7": {
        name: "(anonymous_7)",
        decl: {
          start: {
            line: 171,
            column: 34
          },
          end: {
            line: 171,
            column: 35
          }
        },
        loc: {
          start: {
            line: 171,
            column: 47
          },
          end: {
            line: 173,
            column: 3
          }
        },
        line: 171
      },
      "8": {
        name: "(anonymous_8)",
        decl: {
          start: {
            line: 185,
            column: 1
          },
          end: {
            line: 185,
            column: 2
          }
        },
        loc: {
          start: {
            line: 185,
            column: 25
          },
          end: {
            line: 239,
            column: 2
          }
        },
        line: 185
      },
      "9": {
        name: "(anonymous_9)",
        decl: {
          start: {
            line: 241,
            column: 1
          },
          end: {
            line: 241,
            column: 2
          }
        },
        loc: {
          start: {
            line: 241,
            column: 24
          },
          end: {
            line: 251,
            column: 2
          }
        },
        line: 241
      }
    },
    branchMap: {
      "0": {
        loc: {
          start: {
            line: 35,
            column: 13
          },
          end: {
            line: 35,
            column: 57
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 35,
            column: 13
          },
          end: {
            line: 35,
            column: 24
          }
        }, {
          start: {
            line: 35,
            column: 28
          },
          end: {
            line: 35,
            column: 57
          }
        }],
        line: 35
      },
      "1": {
        loc: {
          start: {
            line: 104,
            column: 2
          },
          end: {
            line: 107,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 104,
            column: 2
          },
          end: {
            line: 107,
            column: 3
          }
        }, {
          start: {
            line: 104,
            column: 2
          },
          end: {
            line: 107,
            column: 3
          }
        }],
        line: 104
      },
      "2": {
        loc: {
          start: {
            line: 121,
            column: 2
          },
          end: {
            line: 123,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 121,
            column: 2
          },
          end: {
            line: 123,
            column: 3
          }
        }, {
          start: {
            line: 121,
            column: 2
          },
          end: {
            line: 123,
            column: 3
          }
        }],
        line: 121
      },
      "3": {
        loc: {
          start: {
            line: 187,
            column: 2
          },
          end: {
            line: 238,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 187,
            column: 2
          },
          end: {
            line: 238,
            column: 3
          }
        }, {
          start: {
            line: 187,
            column: 2
          },
          end: {
            line: 238,
            column: 3
          }
        }],
        line: 187
      },
      "4": {
        loc: {
          start: {
            line: 187,
            column: 6
          },
          end: {
            line: 187,
            column: 74
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 187,
            column: 6
          },
          end: {
            line: 187,
            column: 20
          }
        }, {
          start: {
            line: 187,
            column: 24
          },
          end: {
            line: 187,
            column: 38
          }
        }, {
          start: {
            line: 187,
            column: 42
          },
          end: {
            line: 187,
            column: 57
          }
        }, {
          start: {
            line: 187,
            column: 61
          },
          end: {
            line: 187,
            column: 74
          }
        }],
        line: 187
      },
      "5": {
        loc: {
          start: {
            line: 189,
            column: 3
          },
          end: {
            line: 234,
            column: 4
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 189,
            column: 3
          },
          end: {
            line: 234,
            column: 4
          }
        }, {
          start: {
            line: 189,
            column: 3
          },
          end: {
            line: 234,
            column: 4
          }
        }],
        line: 189
      },
      "6": {
        loc: {
          start: {
            line: 193,
            column: 4
          },
          end: {
            line: 233,
            column: 5
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 193,
            column: 4
          },
          end: {
            line: 233,
            column: 5
          }
        }, {
          start: {
            line: 193,
            column: 4
          },
          end: {
            line: 233,
            column: 5
          }
        }],
        line: 193
      },
      "7": {
        loc: {
          start: {
            line: 193,
            column: 8
          },
          end: {
            line: 193,
            column: 71
          }
        },
        type: "binary-expr",
        locations: [{
          start: {
            line: 193,
            column: 8
          },
          end: {
            line: 193,
            column: 44
          }
        }, {
          start: {
            line: 193,
            column: 48
          },
          end: {
            line: 193,
            column: 71
          }
        }],
        line: 193
      },
      "8": {
        loc: {
          start: {
            line: 195,
            column: 5
          },
          end: {
            line: 216,
            column: 6
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 195,
            column: 5
          },
          end: {
            line: 216,
            column: 6
          }
        }, {
          start: {
            line: 195,
            column: 5
          },
          end: {
            line: 216,
            column: 6
          }
        }],
        line: 195
      },
      "9": {
        loc: {
          start: {
            line: 199,
            column: 6
          },
          end: {
            line: 212,
            column: 7
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 199,
            column: 6
          },
          end: {
            line: 212,
            column: 7
          }
        }, {
          start: {
            line: 199,
            column: 6
          },
          end: {
            line: 212,
            column: 7
          }
        }],
        line: 199
      },
      "10": {
        loc: {
          start: {
            line: 219,
            column: 5
          },
          end: {
            line: 221,
            column: 6
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 219,
            column: 5
          },
          end: {
            line: 221,
            column: 6
          }
        }, {
          start: {
            line: 219,
            column: 5
          },
          end: {
            line: 221,
            column: 6
          }
        }],
        line: 219
      },
      "11": {
        loc: {
          start: {
            line: 242,
            column: 2
          },
          end: {
            line: 242,
            column: 55
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 242,
            column: 2
          },
          end: {
            line: 242,
            column: 55
          }
        }, {
          start: {
            line: 242,
            column: 2
          },
          end: {
            line: 242,
            column: 55
          }
        }],
        line: 242
      },
      "12": {
        loc: {
          start: {
            line: 243,
            column: 24
          },
          end: {
            line: 243,
            column: 80
          }
        },
        type: "cond-expr",
        locations: [{
          start: {
            line: 243,
            column: 38
          },
          end: {
            line: 243,
            column: 53
          }
        }, {
          start: {
            line: 243,
            column: 56
          },
          end: {
            line: 243,
            column: 80
          }
        }],
        line: 243
      },
      "13": {
        loc: {
          start: {
            line: 244,
            column: 2
          },
          end: {
            line: 248,
            column: 3
          }
        },
        type: "if",
        locations: [{
          start: {
            line: 244,
            column: 2
          },
          end: {
            line: 248,
            column: 3
          }
        }, {
          start: {
            line: 244,
            column: 2
          },
          end: {
            line: 248,
            column: 3
          }
        }],
        line: 244
      }
    },
    s: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0,
      "10": 0,
      "11": 0,
      "12": 0,
      "13": 0,
      "14": 0,
      "15": 0,
      "16": 0,
      "17": 0,
      "18": 0,
      "19": 0,
      "20": 0,
      "21": 0,
      "22": 0,
      "23": 0,
      "24": 0,
      "25": 0,
      "26": 0,
      "27": 0,
      "28": 0,
      "29": 0,
      "30": 0,
      "31": 0,
      "32": 0,
      "33": 0,
      "34": 0,
      "35": 0,
      "36": 0,
      "37": 0,
      "38": 0,
      "39": 0,
      "40": 0,
      "41": 0,
      "42": 0,
      "43": 0,
      "44": 0,
      "45": 0,
      "46": 0,
      "47": 0,
      "48": 0,
      "49": 0,
      "50": 0,
      "51": 0,
      "52": 0,
      "53": 0,
      "54": 0,
      "55": 0,
      "56": 0,
      "57": 0,
      "58": 0,
      "59": 0,
      "60": 0,
      "61": 0,
      "62": 0,
      "63": 0,
      "64": 0,
      "65": 0,
      "66": 0,
      "67": 0,
      "68": 0,
      "69": 0,
      "70": 0,
      "71": 0,
      "72": 0,
      "73": 0,
      "74": 0,
      "75": 0,
      "76": 0,
      "77": 0
    },
    f: {
      "0": 0,
      "1": 0,
      "2": 0,
      "3": 0,
      "4": 0,
      "5": 0,
      "6": 0,
      "7": 0,
      "8": 0,
      "9": 0
    },
    b: {
      "0": [0, 0],
      "1": [0, 0],
      "2": [0, 0],
      "3": [0, 0],
      "4": [0, 0, 0, 0],
      "5": [0, 0],
      "6": [0, 0],
      "7": [0, 0],
      "8": [0, 0],
      "9": [0, 0],
      "10": [0, 0],
      "11": [0, 0],
      "12": [0, 0],
      "13": [0, 0]
    },
    _coverageSchema: "43e27e138ebf9cfc5966b082cf9a028302ed4184",
    hash: "0448e8517c583c1aa3782c6d0101826f4f94e83b"
  };
  var coverage = global[gcv] || (global[gcv] = {});

  if (coverage[path] && coverage[path].hash === hash) {
    return coverage[path];
  }

  return coverage[path] = coverageData;
}();

import delegate from 'delegate'; // modules

import Cache from './modules/Cache';
import loadPage from './modules/loadPage';
import renderPage from './modules/renderPage';
import triggerEvent from './modules/triggerEvent';
import on from './modules/on';
import off from './modules/off';
import updateTransition from './modules/updateTransition';
import getAnimationPromises from './modules/getAnimationPromises';
import getPageData from './modules/getPageData';
import { use, unuse, findPlugin } from './modules/plugins';
import { queryAll } from './utils';
import { getDataFromHtml, getCurrentUrl, markSwupElements, Link } from './helpers';
export default class Swup {
  constructor(setOptions) {
    cov_lvhh8p8kb.f[0]++;
    // default options
    let defaults = (cov_lvhh8p8kb.s[0]++, {
      animateHistoryBrowsing: false,
      animationSelector: '[class*="transition-"]',
      linkSelector: `a[href^="${window.location.origin}"]:not([data-no-swup]), a[href^="/"]:not([data-no-swup]), a[href^="#"]:not([data-no-swup])`,
      cache: true,
      containers: ['#swup'],
      requestHeaders: {
        'X-Requested-With': 'swup',
        Accept: 'text/html, application/xhtml+xml'
      },
      plugins: [],
      skipPopStateHandling: function (event) {
        cov_lvhh8p8kb.f[1]++;
        cov_lvhh8p8kb.s[1]++;
        return !((cov_lvhh8p8kb.b[0][0]++, event.state) && (cov_lvhh8p8kb.b[0][1]++, event.state.source === 'swup'));
      }
    }); // merge options

    const options = (cov_lvhh8p8kb.s[2]++, { ...defaults,
      ...setOptions
    }); // handler arrays

    cov_lvhh8p8kb.s[3]++;
    this._handlers = {
      animationInDone: [],
      animationInStart: [],
      animationOutDone: [],
      animationOutStart: [],
      animationSkipped: [],
      clickLink: [],
      contentReplaced: [],
      disabled: [],
      enabled: [],
      openPageInNewTab: [],
      pageLoaded: [],
      pageRetrievedFromCache: [],
      pageView: [],
      popState: [],
      samePage: [],
      samePageWithHash: [],
      serverError: [],
      transitionStart: [],
      transitionEnd: [],
      willReplaceContent: []
    }; // variable for id of element to scroll to after render

    cov_lvhh8p8kb.s[4]++;
    this.scrollToElement = null; // variable for promise used for preload, so no new loading of the same page starts while page is loading

    cov_lvhh8p8kb.s[5]++;
    this.preloadPromise = null; // variable for save options

    cov_lvhh8p8kb.s[6]++;
    this.options = options; // variable for plugins array

    cov_lvhh8p8kb.s[7]++;
    this.plugins = []; // variable for current transition object

    cov_lvhh8p8kb.s[8]++;
    this.transition = {}; // variable for keeping event listeners from "delegate"

    cov_lvhh8p8kb.s[9]++;
    this.delegatedListeners = {}; // make modules accessible in instance

    cov_lvhh8p8kb.s[10]++;
    this.cache = new Cache();
    cov_lvhh8p8kb.s[11]++;
    this.cache.swup = this;
    cov_lvhh8p8kb.s[12]++;
    this.loadPage = loadPage;
    cov_lvhh8p8kb.s[13]++;
    this.renderPage = renderPage;
    cov_lvhh8p8kb.s[14]++;
    this.triggerEvent = triggerEvent;
    cov_lvhh8p8kb.s[15]++;
    this.on = on;
    cov_lvhh8p8kb.s[16]++;
    this.off = off;
    cov_lvhh8p8kb.s[17]++;
    this.updateTransition = updateTransition;
    cov_lvhh8p8kb.s[18]++;
    this.getAnimationPromises = getAnimationPromises;
    cov_lvhh8p8kb.s[19]++;
    this.getPageData = getPageData;
    cov_lvhh8p8kb.s[20]++;

    this.log = () => {
      cov_lvhh8p8kb.f[2]++;
    }; // here so it can be used by plugins


    cov_lvhh8p8kb.s[21]++;
    this.use = use;
    cov_lvhh8p8kb.s[22]++;
    this.unuse = unuse;
    cov_lvhh8p8kb.s[23]++;
    this.findPlugin = findPlugin; // enable swup

    cov_lvhh8p8kb.s[24]++;
    this.enable();
  }

  enable() {
    cov_lvhh8p8kb.f[3]++;
    cov_lvhh8p8kb.s[25]++;

    // check for Promise support
    if (typeof Promise === 'undefined') {
      cov_lvhh8p8kb.b[1][0]++;
      cov_lvhh8p8kb.s[26]++;
      console.warn('Promise is not supported');
      cov_lvhh8p8kb.s[27]++;
      return;
    } else {
      cov_lvhh8p8kb.b[1][1]++;
    } // add event listeners


    cov_lvhh8p8kb.s[28]++;
    this.delegatedListeners.click = delegate(document, this.options.linkSelector, 'click', this.linkClickHandler.bind(this));
    cov_lvhh8p8kb.s[29]++;
    window.addEventListener('popstate', this.popStateHandler.bind(this)); // initial save to cache

    let page = (cov_lvhh8p8kb.s[30]++, getDataFromHtml(document.documentElement.outerHTML, this.options.containers));
    cov_lvhh8p8kb.s[31]++;
    page.url = page.responseURL = getCurrentUrl();
    cov_lvhh8p8kb.s[32]++;

    if (this.options.cache) {
      cov_lvhh8p8kb.b[2][0]++;
      cov_lvhh8p8kb.s[33]++;
      this.cache.cacheUrl(page);
    } else {
      cov_lvhh8p8kb.b[2][1]++;
    } // mark swup blocks in html


    cov_lvhh8p8kb.s[34]++;
    markSwupElements(document.documentElement, this.options.containers); // mount plugins

    cov_lvhh8p8kb.s[35]++;
    this.options.plugins.forEach(plugin => {
      cov_lvhh8p8kb.f[4]++;
      cov_lvhh8p8kb.s[36]++;
      this.use(plugin);
    }); // modify initial history record

    cov_lvhh8p8kb.s[37]++;
    window.history.replaceState(Object.assign({}, window.history.state, {
      url: window.location.href,
      random: Math.random(),
      source: 'swup'
    }), document.title, window.location.href); // trigger enabled event

    cov_lvhh8p8kb.s[38]++;
    this.triggerEvent('enabled'); // add swup-enabled class to html tag

    cov_lvhh8p8kb.s[39]++;
    document.documentElement.classList.add('swup-enabled'); // trigger page view event

    cov_lvhh8p8kb.s[40]++;
    this.triggerEvent('pageView');
  }

  destroy() {
    cov_lvhh8p8kb.f[5]++;
    cov_lvhh8p8kb.s[41]++;
    // remove delegated listeners
    this.delegatedListeners.click.destroy();
    cov_lvhh8p8kb.s[42]++;
    this.delegatedListeners.mouseover.destroy(); // remove popstate listener

    cov_lvhh8p8kb.s[43]++;
    window.removeEventListener('popstate', this.popStateHandler.bind(this)); // empty cache

    cov_lvhh8p8kb.s[44]++;
    this.cache.empty(); // unmount plugins

    cov_lvhh8p8kb.s[45]++;
    this.options.plugins.forEach(plugin => {
      cov_lvhh8p8kb.f[6]++;
      cov_lvhh8p8kb.s[46]++;
      this.unuse(plugin);
    }); // remove swup data atributes from blocks

    cov_lvhh8p8kb.s[47]++;
    queryAll('[data-swup]').forEach(element => {
      cov_lvhh8p8kb.f[7]++;
      cov_lvhh8p8kb.s[48]++;
      element.removeAttribute('data-swup');
    }); // remove handlers

    cov_lvhh8p8kb.s[49]++;
    this.off(); // trigger disable event

    cov_lvhh8p8kb.s[50]++;
    this.triggerEvent('disabled'); // remove swup-enabled class from html tag

    cov_lvhh8p8kb.s[51]++;
    document.documentElement.classList.remove('swup-enabled');
  }

  linkClickHandler(event) {
    cov_lvhh8p8kb.f[8]++;
    cov_lvhh8p8kb.s[52]++;

    // no control key pressed
    if ((cov_lvhh8p8kb.b[4][0]++, !event.metaKey) && (cov_lvhh8p8kb.b[4][1]++, !event.ctrlKey) && (cov_lvhh8p8kb.b[4][2]++, !event.shiftKey) && (cov_lvhh8p8kb.b[4][3]++, !event.altKey)) {
      cov_lvhh8p8kb.b[3][0]++;
      cov_lvhh8p8kb.s[53]++;

      // index of pressed button needs to be checked because Firefox triggers click on all mouse buttons
      if (event.button === 0) {
        cov_lvhh8p8kb.b[5][0]++;
        cov_lvhh8p8kb.s[54]++;
        this.triggerEvent('clickLink', event);
        cov_lvhh8p8kb.s[55]++;
        event.preventDefault();
        const link = (cov_lvhh8p8kb.s[56]++, new Link(event.delegateTarget));
        cov_lvhh8p8kb.s[57]++;

        if ((cov_lvhh8p8kb.b[7][0]++, link.getAddress() == getCurrentUrl()) || (cov_lvhh8p8kb.b[7][1]++, link.getAddress() == '')) {
          cov_lvhh8p8kb.b[6][0]++;
          cov_lvhh8p8kb.s[58]++;

          // link to the same URL
          if (link.getHash() != '') {
            cov_lvhh8p8kb.b[8][0]++;
            cov_lvhh8p8kb.s[59]++;
            // link to the same URL with hash
            this.triggerEvent('samePageWithHash', event);
            const element = (cov_lvhh8p8kb.s[60]++, document.querySelector(link.getHash()));
            cov_lvhh8p8kb.s[61]++;

            if (element != null) {
              cov_lvhh8p8kb.b[9][0]++;
              cov_lvhh8p8kb.s[62]++;
              history.replaceState({
                url: link.getAddress() + link.getHash(),
                random: Math.random(),
                source: 'swup'
              }, document.title, link.getAddress() + link.getHash());
            } else {
              cov_lvhh8p8kb.b[9][1]++;
              cov_lvhh8p8kb.s[63]++;
              // referenced element not found
              console.warn(`Element for offset not found (${link.getHash()})`);
            }
          } else {
            cov_lvhh8p8kb.b[8][1]++;
            cov_lvhh8p8kb.s[64]++;
            // link to the same URL without hash
            this.triggerEvent('samePage', event);
          }
        } else {
          cov_lvhh8p8kb.b[6][1]++;
          cov_lvhh8p8kb.s[65]++;

          // link to different url
          if (link.getHash() != '') {
            cov_lvhh8p8kb.b[10][0]++;
            cov_lvhh8p8kb.s[66]++;
            this.scrollToElement = link.getHash();
          } else {
            cov_lvhh8p8kb.b[10][1]++;
          } // get custom transition from data


          let customTransition = (cov_lvhh8p8kb.s[67]++, event.delegateTarget.getAttribute('data-swup-transition')); // load page

          cov_lvhh8p8kb.s[68]++;
          this.loadPage({
            url: link.getAddress(),
            customTransition: customTransition
          }, false);
        }
      } else {
        cov_lvhh8p8kb.b[5][1]++;
      }
    } else {
      cov_lvhh8p8kb.b[3][1]++;
      cov_lvhh8p8kb.s[69]++;
      // open in new tab (do nothing)
      this.triggerEvent('openPageInNewTab', event);
    }
  }

  popStateHandler(event) {
    cov_lvhh8p8kb.f[9]++;
    cov_lvhh8p8kb.s[70]++;

    if (this.options.skipPopStateHandling(event)) {
      cov_lvhh8p8kb.b[11][0]++;
      cov_lvhh8p8kb.s[71]++;
      return;
    } else {
      cov_lvhh8p8kb.b[11][1]++;
    }

    const link = (cov_lvhh8p8kb.s[72]++, new Link(event.state ? (cov_lvhh8p8kb.b[12][0]++, event.state.url) : (cov_lvhh8p8kb.b[12][1]++, window.location.pathname)));
    cov_lvhh8p8kb.s[73]++;

    if (link.getHash() !== '') {
      cov_lvhh8p8kb.b[13][0]++;
      cov_lvhh8p8kb.s[74]++;
      this.scrollToElement = link.getHash();
    } else {
      cov_lvhh8p8kb.b[13][1]++;
      cov_lvhh8p8kb.s[75]++;
      event.preventDefault();
    }

    cov_lvhh8p8kb.s[76]++;
    this.triggerEvent('popState', event);
    cov_lvhh8p8kb.s[77]++;
    this.loadPage({
      url: link.getAddress()
    }, event);
  }

}