module.exports = require('@swup/prettier-config');
